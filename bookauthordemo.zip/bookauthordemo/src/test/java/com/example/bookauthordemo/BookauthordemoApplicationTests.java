package com.example.bookauthordemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookauthordemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
